/** Automatically generated file. DO NOT MODIFY */
package com.ittus.book_template;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}
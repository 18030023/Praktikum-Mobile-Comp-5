package com.ittus.book_template.model;

public class Bookmark {

	public int partId;
	public int chapId;
	
	public Bookmark(int part, int chap) {
		partId = part;
		chapId = chap;
	}
}
